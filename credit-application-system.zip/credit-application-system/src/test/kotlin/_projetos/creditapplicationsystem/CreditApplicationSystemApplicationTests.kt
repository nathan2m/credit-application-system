package _projetos.creditapplicationsystem

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class CreditApplicationSystemApplicationTests {

	@Test
	fun contextLoads() {
	}

}
